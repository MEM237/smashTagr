// CommandBar.jsx
import React from "react"

export default function CommandBar({ lifeName }) {
  return (
    <div className="w-full h-[45px] bg-[#1a1a1a] text-gray-300 py-1 border-b-4 border-gray-700 font-jura uppercase text-sm flex items-center justify-between px-2">
        <div className="flex-1 text-left"></div>
      <div className="text-center w-full absolute left-0 right-0 pointer-events-none">
        {lifeName}
      </div>
      <div className="flex items-center space-x-2 justify-end">
        <img src="/icons/uZen-icon-txt.svg" alt="icon" className="w-20 h-20" />
      </div>
    </div>
  )
}
