// src/components/VTTX/VTTXAgentDialog.jsx
import React from "react";

export default function VTTXAgentDialog({ logs = [] }) {
  return (
// This is the CORRECT code you need to use
<div className="w-full h-full bg-[#111] rounded-[30px] shadow-inner border border-pink-500 p-4 flex flex-col">      <div className="flex-grow bg-[#222] rounded-[20px] p-2 space-y-2 overflow-y-auto">
        {logs.length ? (
          logs.map((log, i) => (
            <p key={i} className="text-sm break-words text-gray-300">
              {log}
            </p>
          ))
        ) : (
          <p className="text-gray-500 italic">No messages yet.</p>
        )}
      </div>
    </div>
  );
}
