import React, { useEffect, useState } from "react";
import ModuleContainer from "./ModuleContainer";
import VTTXControlPanelLocal from "./VTTXControlPanelLocal";
import VTTXControlPanelRemote from "./VTTXControlPanelRemote";
import VTTXReflexGrid from "./VTTXReflexGrid";
import VTTXAgentDialog from "./VTTXAgentDialog";
import VTTXTextInput from "./VTTXTextInput";
import VTTXAlert from "./VTTXAlert";
import { useApp } from "../../AppContext";
import { mockUsers } from "../../utils/mockUsers"; // Assuming you have mock data

export default function VTTXWindow() {
  const { state, dispatch } = useApp();
  const [localStream, setLocalStream] = useState(null);
  const [visibleModules, setVisibleModules] = useState([]);

  // --- Logic for Camera and Interactivity ---

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => setLocalStream(stream))
      .catch(err => dispatch({ type: 'ADD_LOG', payload: `❌ Camera access denied` }));
  }, [dispatch]);

  const handleTileClick = (id) => {
    const tile = mockUsers[id];
    if (!tile) return;
    console.log("💡 Tile clicked:", id);
    dispatch({ type: 'SET_TARGET_USER', payload: { ...tile, id } });
  };

  const handleSend = (msg) => {
    dispatch({ type: 'ADD_LOG', payload: `🗣️ You: ${msg}` });
  };

  // --- Layout and Component Configuration ---

  const moduleLayouts = {
    local: { x: 728, y: 93, w: 460, h: 240 },
    remote: { x: 260, y: 93, w: 460, h: 240 },
    grid: { x: 828, y: 346, w: 360, h: 540 },
    dialog: { x: 260, y: 353, w: 375, h: 250 },
    input: { x: 260, y: 618, w: 550, h: 270 },
  };

  const components = {
    local: () => <VTTXControlPanelLocal stream={localStream} />,
    remote: () => state.targetUser ? <VTTXControlPanelRemote cmid={state.targetUser.cmid} /> : null,
    grid: () => <VTTXReflexGrid users={mockUsers} onTileClick={handleTileClick} />,
    dialog: () => <VTTXAgentDialog logs={state.logs} />,
    input: () => <VTTXTextInput onSend={handleSend} />,
  };

  // --- Effects for Animations and Alerts ---

  useEffect(() => {
    const moduleKeys = Object.keys(moduleLayouts).filter(key => key !== "remote");
    moduleKeys.forEach((key, index) => {
      setTimeout(() => {
        setVisibleModules(prev => [...prev, key]);
      }, index * 200);
    });
  }, []);

  useEffect(() => {
    if (state.targetUser && !visibleModules.includes("remote")) {
      const timer = setTimeout(() => {
        setVisibleModules(prev => [...prev, "remote"]);
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [state.targetUser, visibleModules]);

  useEffect(() => {
    if (state.targetUser) {
      const timer = setTimeout(() => dispatch({ type: 'SHOW_ALERT' }), 1000);
      return () => clearTimeout(timer);
    }
  }, [state.targetUser, dispatch]);

  return (
    <div className="relative w-[1445px] h-[980px] bg-black">
      {Object.entries(moduleLayouts).map(([key, { x, y, w, h }]) => {
        const isAnimatedIn = visibleModules.includes(key);
        const shouldShow = key === "remote" ? !!state.targetUser && isAnimatedIn : isAnimatedIn;

        console.log(`🔍 ${key}: animated=${isAnimatedIn} show=${shouldShow}`);

        return (
          <ModuleContainer
            key={key}
            x={x}
            y={y}
            w={w}
            h={h}
            isVisible={shouldShow}
          >
            {components[key]()}
          </ModuleContainer>
        );
      })}

      {state.showAlert && (
        <VTTXAlert
          cmid={state.targetUser?.cmid}
          onAccept={() => dispatch({ type: "HIDE_ALERT" })}
          onDecline={() => dispatch({ type: "HIDE_ALERT" })}
        />
      )}
    </div>
  );
}
