// src/components/VTTX/VTTXTextInput.jsx
import React, { useState } from "react";

export default function VTTXTextInput({ onSend }) {
  const [text, setText] = useState("");

  const handleSend = () => {
    if (text.trim()) {
      onSend?.(text.trim());
      setText("");
    }
  };

  return (
// This is the CORRECT code you need to use
    <div className="w-full h-full bg-[#1a1a1a] rounded-[30px] border border-yellow-400 p-4 flex flex-col justify-between">      <textarea
        className="flex-grow resize-none p-2 rounded-[10px] bg-black text-white border border-gray-700 outline-none overflow-y-auto"
        rows={3}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type something..."
      />
      <button
        className="mt-3 bg-pink-500 hover:bg-pink-600 text-white font-bold py-2 px-4 rounded"
        onClick={handleSend}
      >
        Send
      </button>
    </div>
  );
}
