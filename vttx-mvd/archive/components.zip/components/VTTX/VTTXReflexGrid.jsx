// src/components/VTTX/VTTXReflexGrid.jsx
import React from "react";

export default function VTTXReflexGrid({ users = {}, onTileClick }) {
  const grid = Array.from({ length: 12 });
  const seenPairs = new Set();

  return (
    <div className="w-full h-full bg-[#111] rounded-[20px] p-2 shadow-lg flex items-center justify-center">      <div className="flex-grow overflow-y-auto grid grid-cols-3 gap-2 rounded-[20px] bg-[#222] p-2">
        {grid.map((_, i) => {
          const id = `${Math.floor(i / 3)}-${i % 3}`;
          const tile = users[id] || {};
          const cmid = tile?.cmid || "";
          const idit = tile?.idit || "";
          const label = tile.type === "agent" ? `🤖 ${cmid || id}` : cmid || `Tile ${i + 1}`;

          const identityKey = `${cmid}::${idit}`;
          const isDuplicate = cmid && idit && seenPairs.has(identityKey);
          if (!isDuplicate && cmid && idit) seenPairs.add(identityKey);

          return (
            <button
              key={id}
              className="bg-black text-white border border-gray-600 rounded-[10px] py-2 px-2 text-sm break-words hover:bg-gray-800 transition"
              onClick={() => onTileClick?.(id)}
              disabled={isDuplicate}
            >
              {label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
