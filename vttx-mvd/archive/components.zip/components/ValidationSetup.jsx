// ValidationSetup.jsx
import React from "react"
import { useApp } from "../AppContext"

export default function ValidationSetup({ onValidated }) {
  const { dispatch } = useApp()

  const handleValidate = async () => {
    console.log("📸 Requesting camera access...")
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      dispatch({ type: "SET_CAM_PERMISSION", payload: true })
      dispatch({ type: "SET_FEEDSIG", payload: { feedSig: "ictm-draft-001" } })
      onValidated()
    } catch (err) {
      console.error("Camera access denied:", err)
      alert("Camera access required.")
    }
  }

  return (
    <div className="min-h-screen w-full bg-black text-white flex flex-col items-center justify-center relative overflow-hidden">
      <div className="w-[475px] h-[340px] border-[3px] border-orange-400 rounded-[50px] bg-[#1a1a1a] text-white font-jura flex flex-col justify-between items-center text-center px-6 py-4 relative">
        <div className="text-white text-4xl mt-6">Welcome to VTTX</div>
        <div className="text-left text-orange-400 text-4xl w-full px-6 leading-snug">Create your own<br /> presence.</div>
        <div className="text-white text-lg mb-7 animate-pulse-slow">enable camera permissions &gt;</div>
        <button
          onClick={handleValidate}
          className="bg-green-400 w-[60px] h-[100px] rounded-[15px] hover:shadow-[0_0_10px_#00ff8c] absolute right-6 bottom-6"
      ></button>
      </div>
    </div>
  )
}

