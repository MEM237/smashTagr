import React from "react";

// VPN/geolocation cloak detection
// Codename: SPHNΔue
const SPHNΔue = () => (
  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 225 225" width="225" height="225" fill="none">
  <g opacity="100%">
    <rect x="0" y="0" width="225" height="225" fill="#000" rx="0" filter="url(#filter_dshadow_0_0_0_00000014)"></rect>
  </g>
  <g opacity="100%">
    <rect filter="url(#filter_dshadow_0_0_0_00000014)" x="7" y="20" width="212" height="186" fill="#ff2d55" stroke="#ffbeba" stroke-width="6" rx="32"></rect>
    <svg xmlns="http://www.w3.org/2000/svg" height="162" width="162" viewBox="0 0 24 24" fill="#ffbeba" x="32" y="32">
      <path fill="none" d="M0 0h24v24H0z"></path>
      <path d="m19.8 2-8.2 6.7-1.21-1.04 3.6-2.08L9.41 1 8 2.41l2.74 2.74L5 8.46l-1.19 4.29L6.27 17 8 16l-2.03-3.52.35-1.3L9.5 13l.5 9h2l.5-10L21 3.4z"></path>
      <path d="M5 3a2 2 0 1 0 0 4 2 2 0 1 0 0-4z"></path>
    </svg>
  </g>
  <defs>
    <filter id="filter_dshadow_0_0_0_00000014" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse">
      <feFlood flood-opacity="0" result="bg-fix"></feFlood>
      <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="alpha"></feColorMatrix>
      <feOffset dx="0" dy="0"></feOffset>
      <feGaussianBlur stdDeviation="0"></feGaussianBlur>
      <feComposite in2="alpha" operator="out"></feComposite>
      <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.08 0"></feColorMatrix>
      <feBlend mode="normal" in2="bg-fix" result="bg-fix-filter_dshadow_0_0_0_00000014"></feBlend>
      <feBlend in="SourceGraphic" in2="bg-fix-filter_dshadow_0_0_0_00000014" result="shape"></feBlend>
    </filter>
  </defs>
</svg>
);

export default SPHNΔue;
