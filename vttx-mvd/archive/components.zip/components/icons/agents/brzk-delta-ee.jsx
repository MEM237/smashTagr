import React from "react";

// Lineage keeper
// Codename: BRZKΔee
const BRZKΔee = () => (
  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 225 225" width="225" height="225" fill="none">
  <g opacity="100%">
    <rect x="0" y="0" width="225" height="225" fill="#000" rx="0" filter="url(#filter_dshadow_0_0_0_00000014)"></rect>
  </g>
  <g opacity="100%">
    <rect filter="url(#filter_dshadow_0_0_0_00000014)" x="7" y="20" width="212" height="186" fill="#ff2d55" stroke="#ffbeba" stroke-width="6" rx="32"></rect>
    <svg xmlns="http://www.w3.org/2000/svg" height="162" width="162" viewBox="0 0 24 24" fill="#ffbeba" x="32" y="32">
      <path fill="none" d="M0 0h24v24H0z"></path>
      <path d="m17.73 9.01-1.53-.14-.25-1.52C15.63 5.44 13.94 4 12 4c-1.44 0-2.77.78-3.48 2.04l-.49.87-.99.13A3.51 3.51 0 0 0 4 10.5C4 12.43 5.57 14 7.5 14h10a2.5 2.5 0 0 0 2.5-2.5c0-1.28-.99-2.37-2.27-2.49z" opacity=".3"></path>
      <path d="M17.92 7.02C17.45 4.18 14.97 2 12 2 9.82 2 7.83 3.18 6.78 5.06 4.09 5.41 2 7.74 2 10.5 2 13.53 4.47 16 7.5 16h10c2.48 0 4.5-2.02 4.5-4.5a4.5 4.5 0 0 0-4.08-4.48zM17.5 14h-10C5.57 14 4 12.43 4 10.5a3.51 3.51 0 0 1 3.04-3.46l.99-.13.49-.87A3.998 3.998 0 0 1 12 4c1.94 0 3.63 1.44 3.95 3.35l.25 1.52 1.54.14c1.27.12 2.26 1.21 2.26 2.49a2.5 2.5 0 0 1-2.5 2.5zm-2.7 3-2.9 3.32 2 1L11.55 24h2.65l2.9-3.32-2-1L17.45 17zm-6 0-2.9 3.32 2 1L5.55 24H8.2l2.9-3.32-2-1L11.45 17z"></path>
    </svg>
  </g>
  <defs>
    <filter id="filter_dshadow_0_0_0_00000014" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse">
      <feFlood flood-opacity="0" result="bg-fix"></feFlood>
      <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="alpha"></feColorMatrix>
      <feOffset dx="0" dy="0"></feOffset>
      <feGaussianBlur stdDeviation="0"></feGaussianBlur>
      <feComposite in2="alpha" operator="out"></feComposite>
      <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.08 0"></feColorMatrix>
      <feBlend mode="normal" in2="bg-fix" result="bg-fix-filter_dshadow_0_0_0_00000014"></feBlend>
      <feBlend in="SourceGraphic" in2="bg-fix-filter_dshadow_0_0_0_00000014" result="shape"></feBlend>
    </filter>
  </defs>
</svg>
);

export default BRZKΔee;
