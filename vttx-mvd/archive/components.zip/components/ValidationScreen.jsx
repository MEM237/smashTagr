// ValidationScreen.jsx
import React, { useEffect, useRef } from "react"
import { useApp } from "../AppContext"

export default function ValidationScreen({ onComplete }) {
  const { state, dispatch } = useApp()
  const videoRef = useRef(null)
  const feedSig = state.user?.feedSig

  const cmid = "Boaty McBoatface"
  const idit = "bot"

  useEffect(() => {
    console.log("🎥 Initializing cam preview...")
    navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
      if (videoRef.current) videoRef.current.srcObject = stream
    })
    if (feedSig) {
      dispatch({
        type: "SET_HALF_SMASH",
        payload: { cmid, idit, ictm: feedSig }
      })
      console.log("🧠 Identity generated:", { cmid, idit, feedSig })
    }
  }, [dispatch, feedSig])

  return (
    <div className="min-h-screen w-full bg-black text-white flex flex-col items-center justify-center relative">
      <div className="w-[475px] h-[340px] border-[3px] border-orange-400 rounded-[50px] bg-[#1a1a1a] font-jura text-center flex flex-col justify-center items-center relative">
        <video ref={videoRef} autoPlay muted playsInline className="w-[180px] h-[120px] rounded-[15px] object-cover mb-3" />
        <div className="text-3xl mb-3">{cmid}</div>
        <img src={`/icons/user-icon/${idit}.svg`} className="w-[120px] h-[120px] mb-3" />
        <button
          onClick={onComplete}
          className="bg-green-400 w-[60px] h-[100px] rounded-[15px] hover:shadow-[0_0_10px_#00ff8c] absolute right-6 bottom-6"
        ></button>
      </div>
    </div>
  )
}
